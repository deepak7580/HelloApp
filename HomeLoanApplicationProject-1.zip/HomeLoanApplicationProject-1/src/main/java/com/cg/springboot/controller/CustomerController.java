package com.cg.springboot.controller;

import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.cg.springboot.entity.Customer;
import com.cg.springboot.entity.LoanApplication;
import com.cg.springboot.entity.User;
import com.cg.springboot.service.CustomerService;

@RestController
@RequestMapping("/customer")
public class CustomerController {
	
	@Autowired
	CustomerService customerService;
	
	
	//adding single customer into database
	@PostMapping("/addCustomer")
	public Customer addCustomer(@RequestBody Customer customer)
	{
		customerService.addCustomer(customer);
		return customer;
	}
	
	//viewing all the records from the database
	@GetMapping("/viewCustomer")
		public List<Customer> viewCustomer()
	{
		List<Customer> customer=customerService.viewCustomer();
		return customer;
	}
	
	@PostMapping("/login")
	public String login(@RequestBody User user) {
		return customerService.login(user);
	}
	
	@GetMapping("/view/{custId}")
	public Customer viewCustomerById(@PathVariable("custId") String custId)
	{
		Customer customer =  customerService.viewCustomerById(custId);
		return customer;
	}
	
	@PostMapping("/addLoan")
	public LoanApplication addLoan(@RequestBody LoanApplication loan)
	{
		customerService.addLoan(loan);
		return loan;
	}
	
	

}

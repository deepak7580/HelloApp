package com.cg.springboot.dao;







import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.springboot.entity.Customer;
import com.cg.springboot.entity.User;
@Repository
public interface CustomerRepository extends JpaRepository<Customer,String>{

//	@Query("from User where userId=:user AND password=:pwd")
//	User findByIdAndPwd(@Param("user") int user,@Param("pwd") String pwd);


	

	



}

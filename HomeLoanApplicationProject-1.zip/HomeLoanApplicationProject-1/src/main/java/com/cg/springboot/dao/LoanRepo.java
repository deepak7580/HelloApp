package com.cg.springboot.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.springboot.entity.LoanApplication;

public interface LoanRepo extends JpaRepository<LoanApplication, Long> {

}

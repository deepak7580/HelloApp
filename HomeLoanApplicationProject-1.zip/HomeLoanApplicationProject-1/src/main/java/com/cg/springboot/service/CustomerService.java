package com.cg.springboot.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.cg.springboot.entity.Customer;
import com.cg.springboot.entity.LoanApplication;
import com.cg.springboot.entity.User;
@Service
public interface CustomerService {

	void addCustomer(Customer customer);

	List<Customer> viewCustomer();

	Customer viewCustomerById(String custId);

	String login(User user);

	void addLoan(LoanApplication loan);

}

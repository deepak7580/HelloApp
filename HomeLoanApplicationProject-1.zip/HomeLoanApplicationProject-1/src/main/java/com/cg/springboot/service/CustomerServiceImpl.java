package com.cg.springboot.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.springboot.dao.CustomerRepository;
import com.cg.springboot.dao.LoanRepo;
import com.cg.springboot.dao.UserRepo;
import com.cg.springboot.entity.Customer;
import com.cg.springboot.entity.LoanApplication;
import com.cg.springboot.entity.User;


@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerRepository customerRepo;
	@Autowired
	LoanRepo loanRepo;
	@Autowired
	UserRepo userRepo;




	@Override
	public void addCustomer(Customer customer) {
		
		userRepo.save(customer.getUser());
		customerRepo.save(customer);
		
	}



	@Override
	public List<Customer> viewCustomer() {
		// TODO Auto-generated method stub
		List<Customer> customer = customerRepo.findAll();
		return customer;
		
	}



	@Override
	public Customer viewCustomerById(String custId) {
		Optional<Customer> customer= customerRepo.findById(custId);
		
		return customer.get();
		
	}



	@Override
	public String login(User user) {
		// TODO Auto-generated method stub
		String status;
		Optional<Customer> data = customerRepo.findById(user.getUserId());
		
				
		if(data.isPresent())
		{
			status="logged in succssesfully";
	}
		else
		{
			status ="invalid credential";
		}
return status;
	}



	@Override
	public void addLoan(LoanApplication loan) {
		loanRepo.save(loan);
		
	}


}

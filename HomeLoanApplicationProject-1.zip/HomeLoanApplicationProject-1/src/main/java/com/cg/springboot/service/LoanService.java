package com.cg.springboot.service;

import com.cg.springboot.entity.LoanApplication;

public interface LoanService {

	void addLoanApplication(LoanApplication loanApplication);

//	void addLoan(String userId, LoanApplication loanApplication);

}
